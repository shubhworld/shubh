<?php

/**
 * Loaded when a prerelease version is running.
 */

class Cornerstone_Prerelease extends Cornerstone_Plugin_Component {

	public function setup() {

	}

}