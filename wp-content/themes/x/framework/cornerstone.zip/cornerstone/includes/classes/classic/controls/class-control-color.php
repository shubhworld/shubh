<?php
class Cornerstone_Control_Color extends Cornerstone_Control {

	protected $default_context = 'design';

	protected $default_options = array(
		'output_format' => 'hsl'
  );

}