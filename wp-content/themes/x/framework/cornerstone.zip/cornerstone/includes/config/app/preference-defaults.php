<?php

return array(
  'advanced_mode'        => false,
  'help_text'            => true,
  'show_wp_toolbar'      => false,
  'rich_text_default'    => false,
  'ui_theme'             => 'light'
);
