<?php
return array(

  'undefined-title' => __( 'Undefined Element', 'cornerstone' ),
  'region-title'    => __( 'Region', 'cornerstone' ),
  'bar-title'       => __( 'Bar', 'cornerstone' ),
  'container-title' => __( 'Container', 'cornerstone' ),

);
